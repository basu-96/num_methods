function [result] = derivative(x)
    result = 6*x^2 - 2.5;
    %result = x^2;
    %result = exp(-x) * (3.2 * sin(x) - 0.5 * cos(x));
end
